import * as React from 'react';
import Header from './Header'
import DataTable from './DataTable'
import AddBook from './AddBook';
import Home from './Home';
import UpdateBook from './UpdateBook'
import {Routes, Route} from 'react-router-dom'



export default function App()
{
  return (
   
    <>
    <Header />
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path='dashboard' element={<DataTable />}  />
      <Route path='addBook' element={<AddBook />}  />
      <Route path="/updateBook/:id" element={<UpdateBook />} />
      {/* <Route path='login' element={<Login/>} /> */}
    </Routes>
    </>
  );
}