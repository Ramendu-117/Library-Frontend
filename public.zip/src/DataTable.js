import * as React from 'react';
import { useState, useEffect } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { Button, Paper } from '@mui/material';
import myImage from './bgImage2.jpeg';
import productService from './productServices';
import { Link } from 'react-router-dom';



const DataTable = () => {


  const [bookInfo, setBookInfo] = useState([]);

  const columns = [
  { field: 'id', headerName: 'ID', width: 70 },
  { field: 'bookName', headerName: 'Book Name', width: 200 },
  { field: 'author', headerName: 'Author Name', width: 150 },
  { field: 'year', headerName: 'Year of Publication', width: 90 },
  { field: 'availability', headerName: 'Availability', width: 100 },
  {
    field: 'update',
    headerName: 'Update',
    renderCell: (params) => (
      <Button variant="contained" color="success">
        <Link to={`/updateBook/${params.row.id}`}>
        Update
        </Link>
      </Button>
    ),
  },
  {
    field: 'delete',
    headerName: 'Delete',
    renderCell: (params) => (
      <Button
        variant="outlined"
        color="error"
        onClick={() => deleteBook(params.row.id)} 
      >
        Delete
      </Button>
    ),
  },
];

function deleteBook(id) {
  console.log(id + " is yet to be deleted");
  productService.deleteBook(id)
    .then(() => {
      window.alert(id + ": got Deleted");
      init();
    })
    .catch((error) => {
      console.log(error);
    });
    
}

  useEffect(() => {
    init();
  }, []);

  const init =()=>{

        productService.getBooks()
      .then((res) => {
        setBookInfo(res.data);
        console.log(res.data);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  

  return (
    <div
      style={{
        display: 'flex',
        position: 'fixed',
        top: 0,
        left: 0,
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        height: '100%',
        backgroundImage: `url(${myImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
      }}
    >
      <Paper sx={{ height: 500, width: 900, bgcolor: "#FFF2E1", marginTop: 10 }}>
        <DataGrid
          rows={bookInfo.map((row) => ({
            id: row.id, 
            bookName: row.bookName,
            author: row.author,
            year: row.year,
            availability: row.availability,
          }))}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5, 10]}
        />
      </Paper>
    </div>
  );
};

export default DataTable;
