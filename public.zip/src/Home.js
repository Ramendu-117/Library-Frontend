import React from 'react'
import myImage from './bgImage2.jpeg';
import { Box} from '@mui/material';
import Login from './Login';


export default function Home() {

  return (
    
    <Box
      style={{
        display: 'flex',
        position: 'fixed',
        top: 0,
        left: 0,

        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        height: '100%',
        backgroundImage: `url(${myImage})`, 
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
    <Box>
      <Login />
    </Box>
    </Box>

  );


}



