import * as React from 'react';
import { AppProvider, SignInPage } from '@toolpad/core';
import { useTheme } from '@mui/material/styles';
import { Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';


const providers = [{ id: 'credentials', name: 'Email and Password' }];


const signIn = async (provider, formData) => {
  const email = formData.get('email');
  const password = formData.get('password');


  if (email === "ramendu.ghosal2@gmail.com" && password === "ramendu123") {
   
    return { success: true };
  } else {
    
    return { success: false, message: 'Login failed' };
  }
};

export default function Login() {
  const theme = useTheme();
  const navigate = useNavigate(); 

  return (
    <Box
      sx={{
        width: 500,
        height: 500,
        backgroundColor: "#FFF2E1", 
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        margin: 'auto',
        borderRadius: 2,
        boxShadow: 3,
        p: 2, 
        gap: 2, 
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
      }}
    >
      <AppProvider theme={theme}>
        <SignInPage 
          signIn={async (provider, formData) => {
            const result = await signIn(provider, formData);
            if (result.success) {
              navigate('/dashboard'); 
            } else {
              alert(result.message); 
            }
          }} 
          providers={providers} 
        />
      </AppProvider>
    </Box>
  );
}
