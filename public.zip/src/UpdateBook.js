import React, { useEffect, useState } from 'react';
import TextField from '@mui/material/TextField';
import { Box, Button, Typography } from '@mui/material';
import Radio from '@mui/material/Radio';
import myImage from './bgImage2.jpeg';
import { FormControl, FormLabel, RadioGroup, FormControlLabel } from '@mui/material';
import productService from './productServices'
import { useParams } from 'react-router-dom';





export default function UpdateBook() {

const [availability, setAvailability] = useState('');
const {id} = useParams();

  const [book, setBook] = useState({
    id: '',
    bookName: '',
    author: '',
    year: '',
    availability: '',
  });

  useEffect(()=>{
  productService.getBookById(id).then((response) => {
    setBook(response.data)
}).catch((error)=>
{
  console.log(error)
});
}, [id])

  const handleChange = (e) => {
    const { value } = e.target;
    setBook({ ...book,
    [e.target.name]: value});
  };

  const resetradio =()=>
  {
    setAvailability('');
  }

  const changeHandle = (e) => {
    let value = e.target.value;
    setAvailability(value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
   productService.editBook(id, book).then((res)=>{
      window.alert("The book is updated successfully")
    }).catch((error)=>{
      console.log(error);
    })
      setBook({
          id: '',
          bookName: '',
          author: '',
          year: '',
          availability: '',
        
        })
    console.log(book);
  };

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: '100vw',
        height: '100vh',
        backgroundImage: `url(${myImage})`, 
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <Box
        sx={{
          width: 500,
          height: 500,
          backgroundColor: "#FFF2E1", 
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          borderRadius: 2,
          boxShadow: 3,
          p: 2, 
          gap: 2, 
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
        }}
      >
        <Typography variant="h4" sx={{ marginBottom: '20px', marginTop: '5px' }}>
          Update Your Book Here
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            id="outlined-basic"
            label="Enter the Book Name"
            variant="outlined"
            sx={{ paddingBottom: 2 }}
            name="bookName"
            onChange={handleChange}
            value={book.bookName}
          />
          <br />
          <TextField
            id="outlined-basic"
            label="Enter the Author Name"
            variant="outlined"
            sx={{ paddingBottom: 2 }}
            name="author"
            onChange={handleChange}
            value={book.author}
          />
          <br />
          <TextField
            id="outlined-basic"
            type="number"
            label="Enter Published Year"
            variant="outlined"
            sx={{ paddingBottom: 2 }}
            name="year"
            onChange={handleChange}
            value={book.year}
          />
          <br />
          <FormControl component="fieldset">
            <FormLabel component="legend">Check Book Availability</FormLabel>
            <RadioGroup
              aria-label="availability"
              name="availability"
              value={availability}
              onChange={changeHandle}
              
            >
              <FormControlLabel value="Yes" control={<Radio  onChange={(e)=>handleChange(e)} />} label="Available" />
              <FormControlLabel value="No" control={<Radio onChange={(e)=>handleChange(e)}  />} label="Not Available" />
            </RadioGroup>
          </FormControl>
          <br />
          <Button variant="contained" type="submit" onClick={resetradio}>
            Add Book
          </Button>
        </form>
      </Box>
    </Box>
  );
}
