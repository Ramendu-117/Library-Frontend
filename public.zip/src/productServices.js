import axios from 'axios';

const BASE_URL = "http://localhost:8080";

class ProductServices {
  saveBook(book) {
    return axios.post(`${BASE_URL}/addBook`, book);
  }

  getBooks() {
    return axios.get(`${BASE_URL}/getBook`);
  }

  deleteBook(id) {
    return axios.delete(`${BASE_URL}/deleteBook/${id}`);
  }

  editBook(id, book) {
    return axios.put(`${BASE_URL}/updateBook/${id}`, book);
  }

  getBookById(id) {
    return axios.get(`${BASE_URL}/getBook/${id}`);
  }
}


export default new ProductServices();
